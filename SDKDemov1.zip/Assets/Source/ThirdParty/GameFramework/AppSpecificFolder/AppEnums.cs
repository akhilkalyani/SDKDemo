namespace GF
{
    public enum RequestType { }
    public enum HttpRequestType { Get, Post }
}