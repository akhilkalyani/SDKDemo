using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace TPSDK.Constant
{
    public static class ConstantKeysManager
    {
        public static readonly string UserSignInfileName = "UserSignInDetails";
        public static readonly string UserSignInAuthTockenKey = "UserSignInAuthTocken";
    }
}
